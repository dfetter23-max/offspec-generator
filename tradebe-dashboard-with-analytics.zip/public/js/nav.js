// nav.js — Tool switching / navigation logic

function switchTool(toolId, evt) {
  // Update nav
  document.querySelectorAll(".nav-item").forEach(function(el) { el.classList.remove("active"); });
  if (evt && evt.currentTarget) evt.currentTarget.classList.add("active");

  // Hide all tool panels
  document.querySelectorAll(".app, #emaildash, #lookup").forEach(function(el) {
    el.classList.remove("active");
  });

  var mainWrap = document.querySelector(".main-wrap");
  mainWrap.classList.remove("lookup-active", "email-active");

  if (toolId === "lookup") {
    document.getElementById("lookup").classList.add("active");
    mainWrap.classList.add("lookup-active");
  } else if (toolId === "emaildash") {
    document.getElementById("emaildash").classList.add("active");
    mainWrap.classList.add("email-active");
  } else {
    var el = document.getElementById(toolId);
    if (el) el.classList.add("active");
  }

  // Refresh offspec phrases when switching to that tool
  if (toolId === "offspec" && typeof loadPhrasesFromFirebase === "function") {
    loadPhrasesFromFirebase();
  }
  // Load leaderboard when switching to games
  if (toolId === "games" && typeof loadLeaderboard === "function") {
    loadLeaderboard(typeof GAMES_CURRENT !== 'undefined' ? GAMES_CURRENT : 'whackmole');
  }
}
