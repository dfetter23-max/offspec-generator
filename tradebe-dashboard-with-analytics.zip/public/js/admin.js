// admin.js — Centralized admin authentication
// TODO: Replace with Firebase Auth for production security.
// For now, this is a shared admin gate used by offspec phrases, email templates, and lookup.

var ADMIN_PASSWORD = "dfetter"; // FIXME: Move to Firebase Auth before production deploy
var _adminState = {};

/**
 * Check if a specific tool's admin mode is active.
 * @param {string} tool - Tool key ("offspec", "email", "lookup")
 */
function isAdmin(tool) {
  return !!_adminState[tool];
}

/**
 * Set admin state for a tool.
 */
function setAdmin(tool, val) {
  _adminState[tool] = !!val;
}

/**
 * Prompt for admin password and run callback if correct.
 * @param {string} tool - Which tool is requesting admin
 * @param {function} cb - Called on success
 */
function requireAdmin(tool, cb) {
  if (isAdmin(tool)) { cb(); return; }
  var pw = prompt("Admin password:");
  if (pw === null) return;
  if (pw === ADMIN_PASSWORD) {
    setAdmin(tool, true);
    cb();
  } else {
    alert("Incorrect password.");
  }
}
