// games.js — 6 games + shared Firestore leaderboard + help + admin clear

var GAMES_PLAYER = localStorage.getItem('games_player') || '';
var GAMES_CURRENT = 'whackmole';

function gamesEnsurePlayer(cb) {
  if (GAMES_PLAYER) { cb(); return; }
  var name = prompt('Enter your name for the leaderboard:');
  if (!name || !name.trim()) return;
  GAMES_PLAYER = name.trim();
  localStorage.setItem('games_player', GAMES_PLAYER);
  document.getElementById('gPlayerName').textContent = GAMES_PLAYER;
  cb();
}

function gamesChangeName() {
  var name = prompt('Enter new name:', GAMES_PLAYER);
  if (!name || !name.trim()) return;
  GAMES_PLAYER = name.trim();
  localStorage.setItem('games_player', GAMES_PLAYER);
  document.getElementById('gPlayerName').textContent = GAMES_PLAYER;
}

function switchGame(id) {
  GAMES_CURRENT = id;
  document.querySelectorAll('.g-panel').forEach(function(p) { p.style.display = 'none'; });
  document.getElementById('g_' + id).style.display = 'block';
  document.querySelectorAll('.g-tab').forEach(function(t) { t.classList.remove('active'); });
  document.querySelector('.g-tab[data-g="' + id + '"]').classList.add('active');
  loadLeaderboard(id);
}

// ── Help / Rules Popup ──
var GAME_RULES = {
  whackmole: {
    title: 'Whack-a-Mole',
    rules: [
      'Moles pop up in random holes — click them before they disappear!',
      'You have 30 seconds. Each hit = 1 point.',
      'Moles get faster as your score goes up.',
      'Clicking an empty hole does nothing (but you look silly).',
      'Highest score wins!'
    ]
  },
  memory: {
    title: 'Memory Match',
    rules: [
      'Click cards to flip them over — find matching pairs.',
      'You can only flip 2 cards at a time.',
      'If they match, they stay face up. If not, they flip back.',
      'Try to match all 8 pairs in as few moves as possible.',
      'Fewest moves wins!'
    ]
  },
  tetris: {
    title: 'Tetris',
    rules: [
      '\u2190 \u2192 Arrow keys — move piece left/right',
      '\u2191 Arrow key — rotate piece',
      '\u2193 Arrow key — soft drop (faster)',
      'Spacebar — hard drop (instant)',
      'Complete a full row to clear it and score points.',
      'Clearing multiple rows at once scores bonus points.',
      'Game ends when pieces stack to the top.',
      'Highest score wins!'
    ]
  },
  wordscramble: {
    title: 'Word Scramble',
    rules: [
      'A scrambled word appears — type the correct word and hit Enter or Check.',
      'You have 60 seconds. Words come from random categories.',
      'Click Skip if you\u2019re stuck (no penalty, but it burns time).',
      'Categories include: movies, animals, food, sports, countries, and more.',
      'Most correct words in 60 seconds wins!'
    ]
  },
  '2048': {
    title: '2048',
    rules: [
      'Use arrow keys to slide all tiles in one direction.',
      'When two tiles with the same number collide, they merge into one.',
      'A new tile (2 or 4) appears after each move.',
      'Try to create the highest tile possible.',
      'Game ends when no moves are left.',
      'Highest score wins!'
    ]
  },
  flappy: {
    title: 'Flappy Bird',
    rules: [
      'Press Space or click the canvas to flap.',
      'Navigate through the gaps in the green pipes.',
      'Each pipe you pass = 1 point.',
      'Don\u2019t hit the pipes, ground, or ceiling!',
      'Highest score wins!'
    ]
  },
  brickbreaker: {
    title: 'Brick Breaker',
    rules: [
      'Move your mouse to control the paddle.',
      'Bounce the ball to break all the bricks.',
      'Each brick = 10 points.',
      'You have 3 lives \u2014 don\u2019t let the ball fall!',
      'Clear all bricks or survive as long as you can.',
      'Highest score wins!'
    ]
  },
  typing: {
    title: 'Typing Speed',
    rules: [
      'A sentence appears \u2014 type it as fast as you can.',
      'Green letters = correct. Red = wrong.',
      'Your WPM (words per minute) updates live.',
      'The test ends when you type the full sentence.',
      'Highest WPM wins!'
    ]
  },
  wordguess: {
    title: 'Word Guess',
    rules: [
      'Guess the 5-letter word in 6 tries.',
      'Type a word and press Enter to submit.',
      'Green = correct letter, correct position.',
      'Yellow = correct letter, wrong position.',
      'Gray = letter not in the word.',
      'Use the on-screen keyboard or your real one.',
      'Most total wins on the leaderboard!'
    ]
  },
  gemcrush: {
    title: 'Gem Crush',
    rules: [
      'Click a gem, then click an adjacent gem to swap them.',
      'Match 3 or more of the same color in a row or column.',
      'Matched gems disappear and new ones fall in.',
      'Chain reactions score bonus points!',
      'You have 60 seconds.',
      'Highest score wins!'
    ]
  }
};

function showGameHelp(game) {
  var info = GAME_RULES[game];
  if (!info) return;
  var existing = document.getElementById('gameHelpModal');
  if (existing) existing.remove();
  var overlay = document.createElement('div');
  overlay.id = 'gameHelpModal';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.7);z-index:2000;display:flex;align-items:center;justify-content:center;';
  var box = document.createElement('div');
  box.style.cssText = 'background:#131320;border:1px solid #3a3a5a;border-radius:12px;padding:24px;width:400px;max-width:90vw;';
  var h = '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;">';
  h += '<span style="font-family:Syne,sans-serif;font-size:19px;font-weight:700;color:#fff;">' + info.title + '</span>';
  h += '<span onclick="document.getElementById(\'gameHelpModal\').remove()" style="cursor:pointer;color:#888;font-size:20px;">\u2715</span></div>';
  h += '<div style="font-size:14px;color:#bbb;line-height:1.8;">';
  info.rules.forEach(function(r) { h += '<div style="padding:2px 0;">\u2022 ' + r + '</div>'; });
  h += '</div>';
  h += '<div style="margin-top:16px;text-align:right;"><button onclick="document.getElementById(\'gameHelpModal\').remove()" style="padding:6px 20px;background:linear-gradient(135deg,#5b8aff,#7c5bff);border:none;border-radius:6px;color:#fff;font-family:Syne,sans-serif;font-size:15px;font-weight:700;cursor:pointer;">Got it</button></div>';
  box.innerHTML = h;
  overlay.appendChild(box);
  overlay.addEventListener('click', function(e) { if (e.target === overlay) overlay.remove(); });
  document.body.appendChild(overlay);
}

// ── Firestore Leaderboard ──
function postScore(game, score) {
  if (!FIREBASE_DB || !GAMES_PLAYER) return;
  FIREBASE_DB.collection('game_scores').add({
    game: game, name: GAMES_PLAYER, score: score, date: new Date().toISOString()
  }).then(function() { loadLeaderboard(game); }).catch(function(e) { console.warn('Score post failed:', e); });
}

function loadLeaderboard(game) {
  var el = document.getElementById('gLb_' + game);
  if (!el) return;
  if (!FIREBASE_DB) { el.innerHTML = '<div style="color:#666;font-size:13px;">Leaderboard unavailable offline</div>'; return; }
  var isLowerBetter = (game === 'memory');
  FIREBASE_DB.collection('game_scores').get().then(function(snap) {
    var best = {};
    snap.forEach(function(doc) {
      var d = doc.data();
      if (d.game !== game) return;
      if (!best[d.name]) { best[d.name] = d.score; }
      else {
        if (isLowerBetter) { if (d.score < best[d.name]) best[d.name] = d.score; }
        else { if (d.score > best[d.name]) best[d.name] = d.score; }
      }
    });
    var sorted = Object.keys(best).map(function(n) { return { name: n, score: best[n] }; });
    sorted.sort(function(a, b) { return isLowerBetter ? a.score - b.score : b.score - a.score; });
    sorted = sorted.slice(0, 8);
    var html = '';
    sorted.forEach(function(row, i) {
      var medal = i === 0 ? ' g-gold' : '';
      html += '<div class="g-lb-row' + medal + '"><span class="g-lb-rank">' + (i + 1) + '.</span><span class="g-lb-name">' + row.name + '</span><span class="g-lb-score">' + row.score + '</span></div>';
    });
    if (!sorted.length) html = '<div style="color:#666;font-size:13px;">No scores yet \u2014 be the first!</div>';
    if (typeof isAdmin === 'function' && isAdmin('offspec')) {
      html += '<div style="margin-top:8px;text-align:right;"><button onclick="clearLeaderboard(\'' + game + '\')" style="padding:4px 10px;background:transparent;border:1px solid #ff5b5b;border-radius:4px;color:#ff5b5b;font-size:12px;cursor:pointer;font-family:JetBrains Mono,monospace;">Clear board</button></div>';
    }
    el.innerHTML = html;
  }).catch(function(err) { console.error('Leaderboard load failed:', err); el.innerHTML = '<div style="color:#666;font-size:13px;">Could not load scores — check console</div>'; });
}

function clearLeaderboard(game) {
  if (!confirm('Clear ALL scores for ' + game + '? This cannot be undone.')) return;
  if (!FIREBASE_DB) return;
  FIREBASE_DB.collection('game_scores').get().then(function(snap) {
    var batch = FIREBASE_DB.batch();
    snap.forEach(function(doc) {
      if (doc.data().game === game) batch.delete(doc.ref);
    });
    return batch.commit();
  }).then(function() {
    loadLeaderboard(game);
  }).catch(function(e) { alert('Error clearing: ' + e.message); });
}

// ════════════════════════════════════════
// 1. WHACK-A-MOLE
// ════════════════════════════════════════
var wam = { score: 0, timeLeft: 30, active: -1, on: false, moleT: null, clockT: null };

function wamInit() {
  var grid = document.getElementById('wamGrid');
  if (!grid) return;
  grid.innerHTML = '';
  for (var i = 0; i < 16; i++) {
    var h = document.createElement('div'); h.className = 'wam-hole'; h.dataset.i = i;
    var m = document.createElement('div'); m.className = 'wam-mole';
    h.appendChild(m);
    h.addEventListener('click', function() { wamWhack(this); });
    grid.appendChild(h);
  }
}
function wamStart() {
  gamesEnsurePlayer(function() {
    wam.score = 0; wam.timeLeft = 30; wam.on = true; wam.active = -1;
    document.getElementById('wamScore').textContent = '0';
    document.getElementById('wamTimer').textContent = '30s';
    document.getElementById('wamTimer').style.color = '';
    document.getElementById('wamBtn').disabled = true;
    document.getElementById('wamMsg').textContent = '';
    document.getElementById('wamGrid').querySelectorAll('.wam-hole').forEach(function(h) { h.classList.remove('hit', 'miss'); });
    wamPop();
    wam.clockT = setInterval(function() {
      wam.timeLeft--;
      document.getElementById('wamTimer').textContent = wam.timeLeft + 's';
      if (wam.timeLeft <= 5) document.getElementById('wamTimer').style.color = '#E24B4A';
      if (wam.timeLeft <= 0) wamEnd();
    }, 1000);
  });
}
function wamPop() {
  if (!wam.on) return;
  var holes = document.getElementById('wamGrid').querySelectorAll('.wam-hole');
  if (wam.active >= 0) holes[wam.active].querySelector('.wam-mole').classList.remove('up');
  var next; do { next = Math.floor(Math.random() * 16); } while (next === wam.active);
  wam.active = next;
  holes[wam.active].querySelector('.wam-mole').classList.add('up');
  var speed = Math.max(450, 1200 - wam.score * 25);
  wam.moleT = setTimeout(function() {
    if (wam.on && wam.active >= 0) { holes[wam.active].querySelector('.wam-mole').classList.remove('up'); wamPop(); }
  }, speed);
}
function wamWhack(hole) {
  if (!wam.on) return;
  var idx = parseInt(hole.dataset.i);
  if (idx === wam.active) {
    wam.score++; document.getElementById('wamScore').textContent = wam.score;
    hole.classList.add('hit'); hole.querySelector('.wam-mole').classList.remove('up');
    setTimeout(function() { hole.classList.remove('hit'); }, 200);
    clearTimeout(wam.moleT); wam.active = -1; setTimeout(wamPop, 150);
  } else { hole.classList.add('miss'); setTimeout(function() { hole.classList.remove('miss'); }, 200); }
}
function wamEnd() {
  wam.on = false; clearTimeout(wam.moleT); clearInterval(wam.clockT);
  var holes = document.getElementById('wamGrid').querySelectorAll('.wam-hole');
  if (wam.active >= 0) holes[wam.active].querySelector('.wam-mole').classList.remove('up');
  wam.active = -1;
  document.getElementById('wamBtn').disabled = false;
  document.getElementById('wamTimer').style.color = '';
  document.getElementById('wamMsg').textContent = 'Final score: ' + wam.score + '!';
  postScore('whackmole', wam.score);
}

// ════════════════════════════════════════
// 2. MEMORY MATCH
// ════════════════════════════════════════
var mem = { cards: [], flipped: [], matched: 0, moves: 0, locked: false, total: 8 };
var MEM_ICONS = ['\u2660', '\u2665', '\u2666', '\u2663', '\u2605', '\u26A1', '\u266A', '\u2600'];

function memStart() {
  gamesEnsurePlayer(function() {
    mem.matched = 0; mem.moves = 0; mem.locked = false; mem.flipped = [];
    document.getElementById('memMoves').textContent = '0';
    document.getElementById('memMsg').textContent = '';
    var icons = MEM_ICONS.slice(0, mem.total);
    var deck = icons.concat(icons);
    for (var i = deck.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var tmp = deck[i]; deck[i] = deck[j]; deck[j] = tmp; }
    mem.cards = deck;
    var grid = document.getElementById('memGrid'); grid.innerHTML = '';
    deck.forEach(function(icon, idx) {
      var card = document.createElement('div'); card.className = 'mem-card'; card.dataset.i = idx;
      card.innerHTML = '<div class="mem-inner"><div class="mem-front">?</div><div class="mem-back">' + icon + '</div></div>';
      card.addEventListener('click', function() { memFlip(this); });
      grid.appendChild(card);
    });
  });
}
function memFlip(card) {
  if (mem.locked) return;
  var idx = parseInt(card.dataset.i);
  if (card.classList.contains('flipped') || card.classList.contains('matched')) return;
  if (mem.flipped.length >= 2) return;
  card.classList.add('flipped');
  mem.flipped.push({ idx: idx, el: card });
  if (mem.flipped.length === 2) {
    mem.moves++; document.getElementById('memMoves').textContent = mem.moves;
    var a = mem.flipped[0], b = mem.flipped[1];
    if (mem.cards[a.idx] === mem.cards[b.idx]) {
      a.el.classList.add('matched'); b.el.classList.add('matched');
      mem.matched++; mem.flipped = [];
      if (mem.matched === mem.total) {
        document.getElementById('memMsg').textContent = 'Done in ' + mem.moves + ' moves!';
        postScore('memory', mem.moves);
      }
    } else {
      mem.locked = true;
      setTimeout(function() { a.el.classList.remove('flipped'); b.el.classList.remove('flipped'); mem.flipped = []; mem.locked = false; }, 700);
    }
  }
}

// ════════════════════════════════════════
// 3. TETRIS
// ════════════════════════════════════════
var tet = { board: null, piece: null, px: 0, py: 0, pi: 0, score: 0, on: false, timer: null, speed: 500 };
var TET_W = 10, TET_H = 20;
var TET_SHAPES = [[[1,1,1,1]],[[1,1],[1,1]],[[0,1,0],[1,1,1]],[[1,0,0],[1,1,1]],[[0,0,1],[1,1,1]],[[1,1,0],[0,1,1]],[[0,1,1],[1,1,0]]];
var TET_COLORS = ['#00e5ff','#f0c060','#b06ce0','#ff6b35','#5b8aff','#5bff8a','#ff5b8a'];

function tetDraw() {
  var c = document.getElementById('tetCanvas'); if (!c) return;
  var ctx = c.getContext('2d'), sz = 20;
  c.width = TET_W * sz; c.height = TET_H * sz;
  ctx.fillStyle = '#0a0a14'; ctx.fillRect(0, 0, c.width, c.height);
  ctx.strokeStyle = '#1a1a2a';
  for (var x = 0; x <= TET_W; x++) { ctx.beginPath(); ctx.moveTo(x * sz, 0); ctx.lineTo(x * sz, TET_H * sz); ctx.stroke(); }
  for (var y = 0; y <= TET_H; y++) { ctx.beginPath(); ctx.moveTo(0, y * sz); ctx.lineTo(TET_W * sz, y * sz); ctx.stroke(); }
  for (var r = 0; r < TET_H; r++) for (var cl = 0; cl < TET_W; cl++) {
    if (tet.board[r][cl]) { ctx.fillStyle = tet.board[r][cl]; ctx.fillRect(cl * sz + 1, r * sz + 1, sz - 2, sz - 2); }
  }
  if (tet.piece) {
    ctx.fillStyle = TET_COLORS[tet.pi];
    for (var r = 0; r < tet.piece.length; r++) for (var cl = 0; cl < tet.piece[r].length; cl++) {
      if (tet.piece[r][cl]) ctx.fillRect((tet.px + cl) * sz + 1, (tet.py + r) * sz + 1, sz - 2, sz - 2);
    }
  }
}
function tetNew() {
  tet.pi = Math.floor(Math.random() * TET_SHAPES.length);
  tet.piece = TET_SHAPES[tet.pi].map(function(r) { return r.slice(); });
  tet.px = Math.floor((TET_W - tet.piece[0].length) / 2); tet.py = 0;
  if (!tetFits(tet.piece, tet.px, tet.py)) { tetEnd(); return false; }
  return true;
}
function tetFits(piece, px, py) {
  for (var r = 0; r < piece.length; r++) for (var c = 0; c < piece[r].length; c++) {
    if (!piece[r][c]) continue; var nx = px + c, ny = py + r;
    if (nx < 0 || nx >= TET_W || ny >= TET_H) return false;
    if (ny >= 0 && tet.board[ny][nx]) return false;
  } return true;
}
function tetLock() {
  var color = TET_COLORS[tet.pi];
  for (var r = 0; r < tet.piece.length; r++) for (var c = 0; c < tet.piece[r].length; c++) {
    if (tet.piece[r][c] && tet.py + r >= 0) tet.board[tet.py + r][tet.px + c] = color;
  }
  var lines = 0;
  for (var r = TET_H - 1; r >= 0; r--) {
    if (tet.board[r].every(function(v) { return !!v; })) { tet.board.splice(r, 1); tet.board.unshift(new Array(TET_W).fill(null)); lines++; r++; }
  }
  if (lines) { var pts = [0, 100, 300, 500, 800]; tet.score += pts[lines] || lines * 200; tet.speed = Math.max(100, 500 - Math.floor(tet.score / 500) * 30); document.getElementById('tetScore').textContent = tet.score; }
}
function tetRotate() {
  var p = tet.piece, rows = p.length, cols = p[0].length, np = [];
  for (var c = 0; c < cols; c++) { np[c] = []; for (var r = rows - 1; r >= 0; r--) np[c].push(p[r][c]); }
  if (tetFits(np, tet.px, tet.py)) tet.piece = np;
}
function tetMove(dx) { if (tetFits(tet.piece, tet.px + dx, tet.py)) tet.px += dx; }
function tetDrop() {
  if (tetFits(tet.piece, tet.px, tet.py + 1)) tet.py++;
  else { tetLock(); tetNew(); }
  tetDraw();
}
function tetHardDrop() { while (tetFits(tet.piece, tet.px, tet.py + 1)) tet.py++; tetLock(); tetNew(); tetDraw(); }
function tetStart() {
  gamesEnsurePlayer(function() {
    tet.board = [];
    for (var r = 0; r < TET_H; r++) tet.board.push(new Array(TET_W).fill(null));
    tet.score = 0; tet.speed = 500; tet.on = true;
    document.getElementById('tetScore').textContent = '0';
    document.getElementById('tetMsg').textContent = '';
    document.getElementById('tetBtn').disabled = true;
    tetNew(); tetDraw();
    clearInterval(tet.timer);
    tet.timer = setInterval(function() { if (tet.on) tetDrop(); }, tet.speed);
  });
}
function tetEnd() {
  tet.on = false; clearInterval(tet.timer); tet.piece = null; tetDraw();
  document.getElementById('tetBtn').disabled = false;
  document.getElementById('tetMsg').textContent = 'Game over! Score: ' + tet.score;
  postScore('tetris', tet.score);
}
function tetKey(e) {
  if (!tet.on) return;
  if (e.key === 'ArrowLeft') { tetMove(-1); tetDraw(); e.preventDefault(); }
  else if (e.key === 'ArrowRight') { tetMove(1); tetDraw(); e.preventDefault(); }
  else if (e.key === 'ArrowDown') { tetDrop(); e.preventDefault(); }
  else if (e.key === 'ArrowUp') { tetRotate(); tetDraw(); e.preventDefault(); }
  else if (e.key === ' ') { tetHardDrop(); e.preventDefault(); }
}

// ════════════════════════════════════════
// 5. WORD SCRAMBLE
// ════════════════════════════════════════
var WS_CATEGORIES = {
  'Movies': ['inception','gladiator','interstellar','titanic','jaws','avatar','frozen','scarface','aliens','goodfellas','braveheart','departed','godfather','matrix','predator','terminator','beetlejuice','clueless','ghostbusters','shrek'],
  'Animals': ['elephant','giraffe','penguin','dolphin','cheetah','kangaroo','octopus','flamingo','gorilla','butterfly','crocodile','chameleon','hedgehog','platypus','armadillo','porcupine','jellyfish','seahorse','scorpion','tortoise'],
  'Food': ['pepperoni','spaghetti','guacamole','croissant','hamburger','pineapple','cinnamon','chocolate','enchilada','cheesecake','quesadilla','dumpling','pancakes','macaroni','popsicle','meatball','jalapeno','avocado','lasagna','sandwich'],
  'Sports': ['basketball','football','baseball','swimming','volleyball','gymnastics','wrestling','snowboard','badminton','marathon','lacrosse','skateboard','surfing','archery','bowling','fencing','kayaking','cricket','handball','triathlon'],
  'Countries': ['australia','argentina','portugal','thailand','colombia','ethiopia','indonesia','singapore','switzerland','venezuela','cambodia','guatemala','mozambique','nicaragua','pakistan','romania','tanzania','uruguay','zimbabwe','morocco'],
  'Music': ['saxophone','harmonica','accordion','xylophone','tambourine','trombone','mandolin','clarinet','marimba','keyboard','ukulele','triangle','drumstick','amplifier','microphone','headphone','symphony','acoustic','baritone','falsetto'],
  '90s/2000s': ['tamagotchi','blockbuster','discman','playstation','myspace','napster','limewire','motorola','blackberry','geocities','walkman','gameboy','dialup','beeper','floppy','ringtone','chatroom','screensaver','bluetooth','download'],
  'Office Life': ['deadline','meetings','coworker','cubicle','overtime','promotion','schedule','breakroom','paperwork','voicemail','stapler','keyboard','password','printout','calendar','commute','paycheck','training','clipboard','turnover']
};

var ws = { word: '', scrambled: '', found: 0, timeLeft: 60, on: false, timer: null, used: [], cat: '' };

function wsScramble(w) {
  var a = w.split('');
  for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; }
  return a.join('') === w ? wsScramble(w) : a.join('');
}
function wsNext() {
  // Pick random category, then random word from it
  var cats = Object.keys(WS_CATEGORIES);
  var attempts = 0;
  var word, cat;
  do {
    cat = cats[Math.floor(Math.random() * cats.length)];
    var pool = WS_CATEGORIES[cat].filter(function(w) { return ws.used.indexOf(w) < 0; });
    if (pool.length) { word = pool[Math.floor(Math.random() * pool.length)]; }
    attempts++;
  } while (!word && attempts < 50);
  if (!word) { ws.used = []; return wsNext(); }
  ws.word = word;
  ws.cat = cat;
  ws.used.push(ws.word);
  ws.scrambled = wsScramble(ws.word);
  document.getElementById('wsScrambled').textContent = ws.scrambled.toUpperCase();
  document.getElementById('wsCat').textContent = cat;
  document.getElementById('wsInput').value = '';
  document.getElementById('wsInput').focus();
  document.getElementById('wsFeedback').textContent = '';
}
function wsCheck() {
  if (!ws.on) return;
  var guess = document.getElementById('wsInput').value.trim().toLowerCase();
  if (guess === ws.word) {
    ws.found++; document.getElementById('wsFound').textContent = ws.found;
    document.getElementById('wsFeedback').textContent = '\u2705 Correct!';
    document.getElementById('wsFeedback').style.color = '#5bff8a';
    setTimeout(wsNext, 500);
  } else {
    document.getElementById('wsFeedback').textContent = '\u274C Try again';
    document.getElementById('wsFeedback').style.color = '#ff5b5b';
  }
}
function wsSkip() {
  if (!ws.on) return;
  document.getElementById('wsFeedback').textContent = 'It was: ' + ws.word.toUpperCase();
  document.getElementById('wsFeedback').style.color = '#f0c060';
  setTimeout(wsNext, 800);
}
function wsStart() {
  gamesEnsurePlayer(function() {
    ws.found = 0; ws.timeLeft = 60; ws.on = true; ws.used = [];
    document.getElementById('wsFound').textContent = '0';
    document.getElementById('wsTimer').textContent = '60s';
    document.getElementById('wsTimer').style.color = '';
    document.getElementById('wsBtn').disabled = true;
    document.getElementById('wsInput').disabled = false;
    document.getElementById('wsMsg').textContent = '';
    wsNext();
    ws.timer = setInterval(function() {
      ws.timeLeft--;
      document.getElementById('wsTimer').textContent = ws.timeLeft + 's';
      if (ws.timeLeft <= 10) document.getElementById('wsTimer').style.color = '#E24B4A';
      if (ws.timeLeft <= 0) wsEnd();
    }, 1000);
  });
}
function wsEnd() {
  ws.on = false; clearInterval(ws.timer);
  document.getElementById('wsBtn').disabled = false;
  document.getElementById('wsInput').disabled = true;
  document.getElementById('wsFeedback').textContent = '';
  document.getElementById('wsMsg').textContent = 'Time up! You got ' + ws.found + ' words!';
  postScore('wordscramble', ws.found);
}

// ════════════════════════════════════════
// 6. 2048
// ════════════════════════════════════════
var g48 = { board: null, score: 0, on: false };

function g48Add() {
  var empty = [];
  for (var r = 0; r < 4; r++) for (var c = 0; c < 4; c++) { if (!g48.board[r][c]) empty.push({ r: r, c: c }); }
  if (!empty.length) return;
  var cell = empty[Math.floor(Math.random() * empty.length)];
  g48.board[cell.r][cell.c] = Math.random() < 0.9 ? 2 : 4;
}
function g48Draw() {
  var grid = document.getElementById('g48Grid'); if (!grid) return;
  grid.innerHTML = '';
  for (var r = 0; r < 4; r++) for (var c = 0; c < 4; c++) {
    var v = g48.board[r][c];
    var tile = document.createElement('div');
    tile.className = 'g48-tile g48-v' + (v > 2048 ? 'big' : v);
    tile.textContent = v || '';
    grid.appendChild(tile);
  }
  document.getElementById('g48Score').textContent = g48.score;
}
function g48Slide(row) {
  var a = row.filter(function(v) { return v !== 0; }), merged = [];
  for (var i = 0; i < a.length; i++) {
    if (i + 1 < a.length && a[i] === a[i + 1]) { merged.push(a[i] * 2); g48.score += a[i] * 2; i++; }
    else { merged.push(a[i]); }
  }
  while (merged.length < 4) merged.push(0);
  return merged;
}
function g48Move(dir) {
  if (!g48.on) return;
  var b = g48.board, nb = b.map(function(r) { return r.slice(); }), moved = false;
  if (dir === 'left') { for (var r = 0; r < 4; r++) nb[r] = g48Slide(nb[r]); }
  else if (dir === 'right') { for (var r = 0; r < 4; r++) nb[r] = g48Slide(nb[r].reverse()).reverse(); }
  else if (dir === 'up') { for (var c = 0; c < 4; c++) { var col = [nb[0][c],nb[1][c],nb[2][c],nb[3][c]]; col = g48Slide(col); for (var r = 0; r < 4; r++) nb[r][c] = col[r]; } }
  else if (dir === 'down') { for (var c = 0; c < 4; c++) { var col = [nb[3][c],nb[2][c],nb[1][c],nb[0][c]]; col = g48Slide(col); for (var r = 0; r < 4; r++) nb[3-r][c] = col[r]; } }
  for (var r = 0; r < 4; r++) for (var c = 0; c < 4; c++) { if (nb[r][c] !== b[r][c]) moved = true; }
  if (moved) {
    g48.board = nb; g48Add(); g48Draw();
    if (g48CheckEnd()) { g48.on = false; document.getElementById('g48Msg').textContent = 'Game over! Score: ' + g48.score; postScore('2048', g48.score); }
  }
}
function g48CheckEnd() {
  for (var r = 0; r < 4; r++) for (var c = 0; c < 4; c++) {
    if (!g48.board[r][c]) return false;
    if (c < 3 && g48.board[r][c] === g48.board[r][c + 1]) return false;
    if (r < 3 && g48.board[r][c] === g48.board[r + 1][c]) return false;
  } return true;
}
function g48Start() {
  gamesEnsurePlayer(function() {
    g48.board = [[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0]];
    g48.score = 0; g48.on = true;
    g48Add(); g48Add(); g48Draw();
    document.getElementById('g48Msg').textContent = '';
  });
}
function g48Key(e) {
  if (!g48.on) return;
  var map = { ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right' };
  if (map[e.key]) { g48Move(map[e.key]); e.preventDefault(); }
}

// ════════════════════════════════════════
// 7. FLAPPY BIRD
// ════════════════════════════════════════
var flp = { on: false, y: 0, vy: 0, pipes: [], score: 0, frame: 0, timer: null };
var FLP_W = 320, FLP_H = 400, FLP_G = 0.35, FLP_FLAP = -6, FLP_GAP = 120, FLP_PIPE_W = 40, FLP_SPEED = 2.5;

function flpDraw() {
  var c = document.getElementById('flpCanvas'); if (!c) return;
  var ctx = c.getContext('2d');
  c.width = FLP_W; c.height = FLP_H;
  ctx.fillStyle = '#0a0a14'; ctx.fillRect(0, 0, FLP_W, FLP_H);
  // Ground
  ctx.fillStyle = '#1a2a1a'; ctx.fillRect(0, FLP_H - 30, FLP_W, 30);
  // Pipes
  ctx.fillStyle = '#2a9a4a';
  flp.pipes.forEach(function(p) {
    ctx.fillRect(p.x, 0, FLP_PIPE_W, p.top);
    ctx.fillRect(p.x, p.top + FLP_GAP, FLP_PIPE_W, FLP_H - p.top - FLP_GAP);
  });
  // Bird
  ctx.fillStyle = '#f0c060';
  ctx.fillRect(60, flp.y, 20, 16);
  ctx.fillStyle = '#ff6b35';
  ctx.fillRect(76, flp.y + 6, 8, 4);
  // Score
  ctx.fillStyle = '#fff'; ctx.font = 'bold 24px JetBrains Mono, monospace';
  ctx.textAlign = 'center'; ctx.fillText(flp.score, FLP_W / 2, 40);
}

function flpStep() {
  if (!flp.on) return;
  flp.vy += FLP_G;
  flp.y += flp.vy;
  flp.frame++;
  if (flp.frame % 90 === 0) {
    var top = 40 + Math.random() * (FLP_H - FLP_GAP - 100);
    flp.pipes.push({ x: FLP_W, top: top, scored: false });
  }
  for (var i = flp.pipes.length - 1; i >= 0; i--) {
    flp.pipes[i].x -= FLP_SPEED;
    if (flp.pipes[i].x + FLP_PIPE_W < 0) { flp.pipes.splice(i, 1); continue; }
    if (!flp.pipes[i].scored && flp.pipes[i].x + FLP_PIPE_W < 60) {
      flp.score++; flp.pipes[i].scored = true;
      document.getElementById('flpScore').textContent = flp.score;
    }
    if (60 + 20 > flp.pipes[i].x && 60 < flp.pipes[i].x + FLP_PIPE_W) {
      if (flp.y < flp.pipes[i].top || flp.y + 16 > flp.pipes[i].top + FLP_GAP) { flpEnd(); return; }
    }
  }
  if (flp.y + 16 > FLP_H - 30 || flp.y < 0) { flpEnd(); return; }
  flpDraw();
}

function flpFlap() { if (flp.on) flp.vy = FLP_FLAP; }

function flpStart() {
  gamesEnsurePlayer(function() {
    flp.y = FLP_H / 2; flp.vy = 0; flp.pipes = []; flp.score = 0; flp.frame = 0; flp.on = true;
    document.getElementById('flpScore').textContent = '0';
    document.getElementById('flpMsg').textContent = '';
    document.getElementById('flpBtn').disabled = true;
    clearInterval(flp.timer);
    flp.timer = setInterval(flpStep, 1000 / 60);
    flpDraw();
  });
}

function flpEnd() {
  flp.on = false; clearInterval(flp.timer);
  document.getElementById('flpBtn').disabled = false;
  document.getElementById('flpMsg').textContent = 'Score: ' + flp.score + '!';
  postScore('flappy', flp.score);
}

// ════════════════════════════════════════
// 8. BRICK BREAKER
// ════════════════════════════════════════
var brk = { on: false, timer: null, px: 0, bx: 0, by: 0, bdx: 0, bdy: 0, bricks: [], score: 0, lives: 3 };
var BRK_W = 400, BRK_H = 500, BRK_PAD_W = 60, BRK_PAD_H = 10, BRK_BALL_R = 6;
var BRK_COLS = 8, BRK_ROWS = 5, BRK_BW = 45, BRK_BH = 16, BRK_GAP = 4;
var BRK_COLORS = ['#ff5b8a', '#ff6b35', '#f0c060', '#5bff8a', '#5b8aff'];

function brkInitBricks() {
  brk.bricks = [];
  var startX = (BRK_W - (BRK_COLS * (BRK_BW + BRK_GAP) - BRK_GAP)) / 2;
  for (var r = 0; r < BRK_ROWS; r++) for (var c = 0; c < BRK_COLS; c++) {
    brk.bricks.push({ x: startX + c * (BRK_BW + BRK_GAP), y: 40 + r * (BRK_BH + BRK_GAP), alive: true, color: BRK_COLORS[r] });
  }
}

function brkDraw() {
  var c = document.getElementById('brkCanvas'); if (!c) return;
  var ctx = c.getContext('2d');
  c.width = BRK_W; c.height = BRK_H;
  ctx.fillStyle = '#0a0a14'; ctx.fillRect(0, 0, BRK_W, BRK_H);
  // Bricks
  brk.bricks.forEach(function(b) {
    if (!b.alive) return;
    ctx.fillStyle = b.color; ctx.fillRect(b.x, b.y, BRK_BW, BRK_BH);
  });
  // Paddle
  ctx.fillStyle = '#ccc'; ctx.fillRect(brk.px - BRK_PAD_W / 2, BRK_H - 30, BRK_PAD_W, BRK_PAD_H);
  // Ball
  ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(brk.bx, brk.by, BRK_BALL_R, 0, Math.PI * 2); ctx.fill();
  // HUD
  ctx.fillStyle = '#888'; ctx.font = '13px JetBrains Mono, monospace'; ctx.textAlign = 'left';
  ctx.fillText('Score: ' + brk.score, 10, BRK_H - 8);
  ctx.textAlign = 'right'; ctx.fillText('Lives: ' + brk.lives, BRK_W - 10, BRK_H - 8);
}

function brkStep() {
  if (!brk.on) return;
  brk.bx += brk.bdx; brk.by += brk.bdy;
  // Wall bounce
  if (brk.bx - BRK_BALL_R <= 0 || brk.bx + BRK_BALL_R >= BRK_W) brk.bdx = -brk.bdx;
  if (brk.by - BRK_BALL_R <= 0) brk.bdy = -brk.bdy;
  // Paddle bounce
  if (brk.bdy > 0 && brk.by + BRK_BALL_R >= BRK_H - 30 && brk.by + BRK_BALL_R <= BRK_H - 20 &&
      brk.bx >= brk.px - BRK_PAD_W / 2 && brk.bx <= brk.px + BRK_PAD_W / 2) {
    brk.bdy = -brk.bdy;
    var offset = (brk.bx - brk.px) / (BRK_PAD_W / 2);
    brk.bdx = offset * 4;
  }
  // Ball lost
  if (brk.by > BRK_H) {
    brk.lives--;
    if (brk.lives <= 0) { brkEnd(); return; }
    brk.bx = BRK_W / 2; brk.by = BRK_H - 50; brk.bdx = 2; brk.bdy = -3;
  }
  // Brick collision
  var allDead = true;
  brk.bricks.forEach(function(b) {
    if (!b.alive) return; allDead = false;
    if (brk.bx + BRK_BALL_R > b.x && brk.bx - BRK_BALL_R < b.x + BRK_BW &&
        brk.by + BRK_BALL_R > b.y && brk.by - BRK_BALL_R < b.y + BRK_BH) {
      b.alive = false; brk.bdy = -brk.bdy; brk.score += 10;
      document.getElementById('brkScore').textContent = brk.score;
    }
  });
  if (allDead) { brkEnd(); return; }
  brkDraw();
}

function brkStart() {
  gamesEnsurePlayer(function() {
    brk.px = BRK_W / 2; brk.bx = BRK_W / 2; brk.by = BRK_H - 50;
    brk.bdx = 2; brk.bdy = -3; brk.score = 0; brk.lives = 3; brk.on = true;
    brkInitBricks();
    document.getElementById('brkScore').textContent = '0';
    document.getElementById('brkMsg').textContent = '';
    document.getElementById('brkBtn').disabled = true;
    clearInterval(brk.timer);
    brk.timer = setInterval(brkStep, 1000 / 60);
    brkDraw();
  });
}

function brkEnd() {
  brk.on = false; clearInterval(brk.timer);
  document.getElementById('brkBtn').disabled = false;
  document.getElementById('brkMsg').textContent = 'Score: ' + brk.score + '!';
  postScore('brickbreaker', brk.score);
}

function brkMouseMove(e) {
  if (!brk.on) return;
  var c = document.getElementById('brkCanvas');
  var rect = c.getBoundingClientRect();
  brk.px = (e.clientX - rect.left) * (BRK_W / rect.width);
}

// ════════════════════════════════════════
// 10. TYPING SPEED
// ════════════════════════════════════════
var TYPE_SENTENCES = [
  'the quick brown fox jumps over the lazy dog',
  'hazardous waste requires careful handling at all times',
  'a journey of a thousand miles begins with a single step',
  'every receiving dock tells a story if you pay attention',
  'the manifest must match the shipping documentation exactly',
  'safety glasses are required in all operational areas',
  'proper labeling prevents costly mistakes down the line',
  'teamwork makes the dream work especially on monday morning',
  'coffee is the fuel that powers the receiving department',
  'if you can read this you type faster than you think',
  'the best time to organize is before the truck arrives',
  'compliance is not optional it is essential to operations',
  'forklift operators must be certified before operating equipment',
  'a clean workspace is a safe workspace remember that always',
  'double check the weight ticket before signing any paperwork'
];
var typ = { on: false, sentence: '', typed: '', startTime: 0, timer: null, wpm: 0 };

function typStart() {
  gamesEnsurePlayer(function() {
    typ.sentence = TYPE_SENTENCES[Math.floor(Math.random() * TYPE_SENTENCES.length)];
    typ.typed = ''; typ.wpm = 0; typ.on = true;
    document.getElementById('typTarget').textContent = typ.sentence;
    document.getElementById('typInput').value = '';
    document.getElementById('typInput').disabled = false;
    document.getElementById('typInput').focus();
    document.getElementById('typWpm').textContent = '0';
    document.getElementById('typMsg').textContent = '';
    document.getElementById('typBtn').disabled = true;
    typ.startTime = performance.now();
    clearInterval(typ.timer);
    typ.timer = setInterval(function() {
      if (!typ.on) return;
      var elapsed = (performance.now() - typ.startTime) / 60000;
      var words = typ.typed.trim().split(/\s+/).filter(function(w) { return w.length > 0; }).length;
      typ.wpm = elapsed > 0 ? Math.round(words / elapsed) : 0;
      document.getElementById('typWpm').textContent = typ.wpm;
    }, 500);
  });
}

function typOnInput() {
  if (!typ.on) return;
  typ.typed = document.getElementById('typInput').value;
  // Highlight correct/incorrect
  var target = typ.sentence;
  var html = '';
  for (var i = 0; i < target.length; i++) {
    if (i < typ.typed.length) {
      if (typ.typed[i] === target[i]) html += '<span style="color:#5bff8a">' + target[i] + '</span>';
      else html += '<span style="color:#ff5b5b;text-decoration:underline">' + target[i] + '</span>';
    } else {
      html += '<span style="color:#666">' + target[i] + '</span>';
    }
  }
  document.getElementById('typTarget').innerHTML = html;
  // Check completion
  if (typ.typed === typ.sentence) typEnd();
}

function typEnd() {
  typ.on = false; clearInterval(typ.timer);
  var elapsed = (performance.now() - typ.startTime) / 60000;
  var words = typ.sentence.trim().split(/\s+/).length;
  typ.wpm = Math.round(words / elapsed);
  document.getElementById('typWpm').textContent = typ.wpm;
  document.getElementById('typInput').disabled = true;
  document.getElementById('typBtn').disabled = false;
  document.getElementById('typMsg').textContent = 'Done! ' + typ.wpm + ' WPM!';
  postScore('typing', typ.wpm);
}

// ════════════════════════════════════════
// WORD GUESS (Wordle-style)
// ════════════════════════════════════════
var WG_WORDS = ['about','above','abuse','actor','acute','admit','adopt','adult','agent','agree','ahead','alarm','album','alert','alien','align','alive','allow','alone','alter','among','anger','angle','apple','apply','arena','argue','arise','armor','array','aside','asset','audio','audit','avoid','basic','beach','begin','being','below','bench','birth','black','blade','blame','blank','blast','blaze','bleed','blend','blind','block','blood','bloom','blown','board','bonus','boost','bound','brain','brand','brave','bread','break','breed','brick','brief','bring','broad','brown','brush','build','burst','buyer','cabin','cable','carry','catch','cause','chain','chair','chaos','charm','chart','chase','cheap','check','chest','chief','child','china','chose','chunk','civil','claim','class','clean','clear','climb','clock','clone','close','cloud','coach','coast','count','court','cover','crack','craft','crash','crazy','cream','crime','cross','crowd','crown','crush','curve','cycle','daily','dance','death','debut','delay','dense','depth','derby','devil','dirty','doubt','dozen','draft','drain','drama','drawn','dream','dress','dried','drift','drill','drink','drive','drove','dying','eager','early','earth','eight','elder','elect','elite','empty','enemy','enjoy','enter','entry','equal','error','essay','event','every','exact','exist','extra','faith','false','fancy','fatal','fault','favor','feast','fence','fever','fiber','field','fifth','fifty','fight','final','first','fixed','flame','flash','flesh','float','flood','floor','fluid','focus','force','forge','forth','forum','found','frame','frank','fraud','fresh','front','fruit','fully','giant','given','glass','globe','going','grace','grade','grain','grand','grant','graph','grasp','grass','grave','great','green','gross','group','grown','guard','guess','guide','guilt','habit','happy','harsh','heart','heavy','hence','herbs','horse','hotel','house','human','humor','hurry','ideal','image','imply','index','inner','input','intro','issue','ivory','joint','judge','juice','knife','knock','known','label','labor','large','laser','later','laugh','layer','learn','lease','legal','level','light','limit','liver','local','logic','loose','lover','lower','lucky','lunch','lyric','magic','major','maker','march','match','mayor','media','mercy','merit','metal','minor','minus','model','money','month','moral','motor','mount','mouse','mouth','movie','music','naked','nerve','never','night','noble','noise','north','novel','nurse','nylon','occur','ocean','offer','often','olive','onset','opera','orbit','order','organ','other','outer','owner','oxide','ozone','paint','panic','paper','patch','pause','peace','pearl','penny','phase','phone','photo','piano','piece','pilot','pitch','pixel','place','plain','plane','plant','plate','plaza','plead','plumb','point','polar','pound','power','press','price','pride','prime','print','prior','prize','probe','proof','proud','prove','pulse','punch','pupil','queen','query','quest','quick','quiet','quota','quote','radar','radio','raise','ranch','range','rapid','ratio','reach','ready','realm','rebel','refer','reign','relax','reply','ridge','rifle','rigid','rival','river','robot','rocky','roger','roman','rough','round','route','royal','rugby','ruler','rural','saint','salad','sauce','scale','scene','scope','score','sense','serve','seven','shall','shape','share','sharp','sheet','shelf','shell','shift','shine','shirt','shock','shore','short','shout','sight','sigma','since','sixth','sixty','skill','slate','sleep','slice','slide','slope','smart','smell','smile','smoke','solar','solid','solve','sorry','south','space','spare','speak','speed','spell','spend','spill','spine','spite','split','spoke','spray','squad','stack','staff','stage','stake','stand','start','state','steam','steel','steep','steer','stern','stick','still','stock','stone','stood','store','storm','story','stove','stuff','style','sugar','suite','super','surge','swamp','swear','sweep','sweet','swept','swift','swing','sword','swore','sworn','syrup','table','taste','teach','teeth','thank','theme','thick','thing','think','third','those','three','throw','thumb','tight','timer','tired','title','today','token','topic','total','touch','tough','tower','toxic','trace','track','trade','trail','train','trait','trash','treat','trend','trial','tribe','trick','tried','troop','truck','truly','trump','trunk','trust','truth','tumor','twice','twist','ultra','under','union','unite','unity','until','upper','upset','urban','usage','usual','utter','valid','value','valve','vapor','venue','verse','video','vigor','viral','virus','visit','vital','vivid','vocal','voice','voter','wages','watch','water','weave','weigh','weird','whale','wheat','wheel','where','which','while','white','whole','whose','wider','woman','woods','world','worry','worse','worst','worth','would','wound','wrist','write','wrote','yield','young','youth'];
var wg = { word: '', guesses: [], current: '', on: false, won: false, wins: 0 };

function wgStart() {
  gamesEnsurePlayer(function() {
    wg.word = WG_WORDS[Math.floor(Math.random() * WG_WORDS.length)];
    wg.guesses = []; wg.current = ''; wg.on = true; wg.won = false;
    document.getElementById('wgRound').textContent = '0';
    document.getElementById('wgMsg').textContent = '';
    document.getElementById('wgBtn').disabled = true;
    wgRender();
  });
}

function wgRender() {
  // Board
  var html = '';
  for (var r = 0; r < 6; r++) {
    html += '<div class="wg-row">';
    var guess = wg.guesses[r] || '';
    var isCurrentRow = (r === wg.guesses.length && wg.on);
    for (var c = 0; c < 5; c++) {
      var letter = '', cls = 'wg-cell';
      if (r < wg.guesses.length) {
        letter = guess[c] || '';
        var wordArr = wg.word.split('');
        var guessArr = guess.split('');
        // Determine color
        if (letter === wg.word[c]) { cls += ' wg-correct'; }
        else if (wg.word.indexOf(letter) >= 0) { cls += ' wg-present'; }
        else { cls += ' wg-absent'; }
      } else if (isCurrentRow) {
        letter = (wg.current[c] || '').toUpperCase();
        if (letter) cls += ' wg-filled';
      }
      html += '<div class="' + cls + '">' + (letter ? letter.toUpperCase() : '') + '</div>';
    }
    html += '</div>';
  }
  document.getElementById('wgBoard').innerHTML = html;
  // Keyboard
  var rows = ['qwertyuiop', 'asdfghjkl', 'zxcvbnm'];
  var kbHtml = '';
  var used = {};
  wg.guesses.forEach(function(g) {
    for (var i = 0; i < g.length; i++) {
      var l = g[i];
      if (l === wg.word[i]) used[l] = 'wg-k-correct';
      else if (wg.word.indexOf(l) >= 0 && used[l] !== 'wg-k-correct') used[l] = 'wg-k-present';
      else if (!used[l]) used[l] = 'wg-k-absent';
    }
  });
  rows.forEach(function(row, ri) {
    kbHtml += '<div class="wg-kb-row">';
    if (ri === 2) kbHtml += '<div class="wg-key wg-key-wide" onclick="wgKeyPress(\'ENTER\')">ENT</div>';
    for (var i = 0; i < row.length; i++) {
      var k = row[i], cls = used[k] || '';
      kbHtml += '<div class="wg-key ' + cls + '" onclick="wgKeyPress(\'' + k + '\')">' + k.toUpperCase() + '</div>';
    }
    if (ri === 2) kbHtml += '<div class="wg-key wg-key-wide" onclick="wgKeyPress(\'BACK\')">DEL</div>';
    kbHtml += '</div>';
  });
  document.getElementById('wgKeyboard').innerHTML = kbHtml;
}

function wgKeyPress(k) {
  if (!wg.on) return;
  if (k === 'BACK') { wg.current = wg.current.slice(0, -1); wgRender(); return; }
  if (k === 'ENTER') { wgSubmit(); return; }
  if (wg.current.length < 5) { wg.current += k.toLowerCase(); wgRender(); }
}

function wgSubmit() {
  if (wg.current.length !== 5) { document.getElementById('wgMsg').textContent = 'Need 5 letters'; return; }
  wg.guesses.push(wg.current);
  document.getElementById('wgRound').textContent = wg.guesses.length;
  if (wg.current === wg.word) {
    wg.on = false; wg.won = true;
    document.getElementById('wgMsg').textContent = 'You got it in ' + wg.guesses.length + '!';
    document.getElementById('wgBtn').disabled = false;
    wg.wins++;
    postScore('wordguess', wg.wins);
  } else if (wg.guesses.length >= 6) {
    wg.on = false;
    document.getElementById('wgMsg').textContent = 'It was: ' + wg.word.toUpperCase();
    document.getElementById('wgBtn').disabled = false;
  }
  wg.current = '';
  wgRender();
}

function wgKey(e) {
  if (!wg.on) return;
  if (e.key === 'Enter') { wgSubmit(); e.preventDefault(); }
  else if (e.key === 'Backspace') { wg.current = wg.current.slice(0, -1); wgRender(); e.preventDefault(); }
  else if (/^[a-zA-Z]$/.test(e.key) && wg.current.length < 5) { wg.current += e.key.toLowerCase(); wgRender(); }
}

// ════════════════════════════════════════
// GEM CRUSH (Candy Crush-style match-3)
// ════════════════════════════════════════
var gc = { board: null, sel: null, score: 0, on: false, timer: null, timeLeft: 60, cols: 7, rows: 7, animating: false };
var GC_GEMS = ['#ff5b5b', '#5b8aff', '#5bff8a', '#f0c060', '#b06ce0', '#ff6b35'];
var GC_SHAPES = ['\u25cf', '\u25a0', '\u25b2', '\u2666', '\u2605', '\u2764'];

function gcRand() { return Math.floor(Math.random() * GC_GEMS.length); }

function gcInit() {
  gc.board = [];
  for (var r = 0; r < gc.rows; r++) {
    gc.board[r] = [];
    for (var c = 0; c < gc.cols; c++) {
      var g;
      do { g = gcRand(); } while (
        (c >= 2 && gc.board[r][c-1] === g && gc.board[r][c-2] === g) ||
        (r >= 2 && gc.board[r-1][c] === g && gc.board[r-2][c] === g)
      );
      gc.board[r][c] = g;
    }
  }
}

function gcDraw() {
  var el = document.getElementById('gcBoard'); if (!el) return;
  var html = '';
  for (var r = 0; r < gc.rows; r++) {
    for (var c = 0; c < gc.cols; c++) {
      var g = gc.board[r][c];
      var selected = gc.sel && gc.sel.r === r && gc.sel.c === c;
      var cls = 'gc-gem' + (selected ? ' gc-sel' : '') + (g < 0 ? ' gc-empty' : '');
      html += '<div class="' + cls + '" data-r="' + r + '" data-c="' + c + '" style="color:' + (g >= 0 ? GC_GEMS[g] : 'transparent') + '">' + (g >= 0 ? GC_SHAPES[g] : '') + '</div>';
    }
  }
  el.innerHTML = html;
  el.querySelectorAll('.gc-gem').forEach(function(gem) {
    gem.addEventListener('click', function() { gcClick(parseInt(this.dataset.r), parseInt(this.dataset.c)); });
  });
}

function gcClick(r, c) {
  if (!gc.on || gc.animating) return;
  if (gc.board[r][c] < 0) return;
  if (!gc.sel) { gc.sel = { r: r, c: c }; gcDraw(); return; }
  var dr = Math.abs(gc.sel.r - r), dc = Math.abs(gc.sel.c - c);
  if ((dr === 1 && dc === 0) || (dr === 0 && dc === 1)) {
    gcSwap(gc.sel.r, gc.sel.c, r, c);
    var matches = gcFindMatches();
    if (matches.length) {
      gc.sel = null;
      gcProcessMatches(matches);
    } else {
      gcSwap(gc.sel.r, gc.sel.c, r, c);
      gc.sel = null;
      gcDraw();
    }
  } else {
    gc.sel = { r: r, c: c };
    gcDraw();
  }
}

function gcSwap(r1, c1, r2, c2) {
  var tmp = gc.board[r1][c1];
  gc.board[r1][c1] = gc.board[r2][c2];
  gc.board[r2][c2] = tmp;
}

function gcFindMatches() {
  var matched = [];
  // Horizontal
  for (var r = 0; r < gc.rows; r++) {
    for (var c = 0; c < gc.cols - 2; c++) {
      var g = gc.board[r][c]; if (g < 0) continue;
      if (gc.board[r][c+1] === g && gc.board[r][c+2] === g) {
        var end = c + 2;
        while (end + 1 < gc.cols && gc.board[r][end+1] === g) end++;
        for (var i = c; i <= end; i++) matched.push(r + ',' + i);
        c = end;
      }
    }
  }
  // Vertical
  for (var c = 0; c < gc.cols; c++) {
    for (var r = 0; r < gc.rows - 2; r++) {
      var g = gc.board[r][c]; if (g < 0) continue;
      if (gc.board[r+1][c] === g && gc.board[r+2][c] === g) {
        var end = r + 2;
        while (end + 1 < gc.rows && gc.board[end+1][c] === g) end++;
        for (var i = r; i <= end; i++) matched.push(i + ',' + c);
        r = end;
      }
    }
  }
  // Deduplicate
  return matched.filter(function(v, i, a) { return a.indexOf(v) === i; });
}

function gcProcessMatches(matches) {
  gc.animating = true;
  gc.score += matches.length * 10;
  document.getElementById('gcScore').textContent = gc.score;
  matches.forEach(function(m) {
    var parts = m.split(',');
    gc.board[parseInt(parts[0])][parseInt(parts[1])] = -1;
  });
  gcDraw();
  setTimeout(function() {
    gcDropGems();
    gcDraw();
    setTimeout(function() {
      var newMatches = gcFindMatches();
      if (newMatches.length) {
        gcProcessMatches(newMatches);
      } else {
        gc.animating = false;
      }
    }, 200);
  }, 250);
}

function gcDropGems() {
  for (var c = 0; c < gc.cols; c++) {
    var empty = 0;
    for (var r = gc.rows - 1; r >= 0; r--) {
      if (gc.board[r][c] < 0) { empty++; }
      else if (empty > 0) { gc.board[r + empty][c] = gc.board[r][c]; gc.board[r][c] = -1; }
    }
    for (var r = 0; r < empty; r++) { gc.board[r][c] = gcRand(); }
  }
}

function gcStart() {
  gamesEnsurePlayer(function() {
    gc.score = 0; gc.timeLeft = 60; gc.on = true; gc.sel = null; gc.animating = false;
    gcInit(); gcDraw();
    document.getElementById('gcScore').textContent = '0';
    document.getElementById('gcTimer').textContent = '60s';
    document.getElementById('gcTimer').style.color = '';
    document.getElementById('gcMsg').textContent = '';
    document.getElementById('gcBtn').disabled = true;
    clearInterval(gc.timer);
    gc.timer = setInterval(function() {
      gc.timeLeft--;
      document.getElementById('gcTimer').textContent = gc.timeLeft + 's';
      if (gc.timeLeft <= 10) document.getElementById('gcTimer').style.color = '#E24B4A';
      if (gc.timeLeft <= 0) gcEnd();
    }, 1000);
  });
}

function gcEnd() {
  gc.on = false; clearInterval(gc.timer);
  document.getElementById('gcBtn').disabled = false;
  document.getElementById('gcMsg').textContent = 'Score: ' + gc.score + '!';
  postScore('gemcrush', gc.score);
}

// ── Global Key Handler ──
document.addEventListener('keydown', function(e) {
  if (GAMES_CURRENT === 'tetris') tetKey(e);
  else if (GAMES_CURRENT === '2048') g48Key(e);
  else if (GAMES_CURRENT === 'flappy') { if (e.key === ' ') { flpFlap(); e.preventDefault(); } }
  else if (GAMES_CURRENT === 'wordguess') wgKey(e);
});

// ── Init ──
window.addEventListener('DOMContentLoaded', function() {
  if (GAMES_PLAYER) document.getElementById('gPlayerName').textContent = GAMES_PLAYER;
  wamInit();
  onFirebaseReady(function() { loadLeaderboard('whackmole'); });
});
